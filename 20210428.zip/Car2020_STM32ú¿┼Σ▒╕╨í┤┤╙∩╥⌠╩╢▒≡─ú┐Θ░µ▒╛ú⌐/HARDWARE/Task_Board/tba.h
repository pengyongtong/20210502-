#ifndef __TBA_H
#define __TBA_H

#include "sys.h"

#define L_LED  0x01
#define R_LED  0x02

#define Tba_LED_K  0
#define Tba_LED_G  1

#define Tba_R_LED PHout(11) 
#define Tba_L_LED PHout(10) 

#define Tba_BEEP PCout(13)
#define Tba_K_BEEP	 {PCout(13)=RESET;}
#define Tba_G_BEEP   {PCout(13)=SET;}
//#define 

void Tba_Init(void);
uint8_t Get_tba_phsis_value(void);
void Set_tba_Beep(uint8_t swch);
void Set_tba_WheelLED(uint8_t LorR,uint8_t swch);

#endif

