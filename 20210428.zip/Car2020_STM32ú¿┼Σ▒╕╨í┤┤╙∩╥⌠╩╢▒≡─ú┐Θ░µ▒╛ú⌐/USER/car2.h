#ifndef __CAR2_H
#define __CAR2_H 			   
#include "stm32f4xx.h"	
#define CAR2_USE    0


extern u8  gucCar2State;
extern u8  gucCar2GuangMin;
extern u16  guiCar2ChaoSB;
extern u16  guiCar2GuangQ;
extern u16  guiCar2MaPan;
void car2_proc(void);
void car2_cmd(u8 ucCmdMain,u8 ucCmdS1,u8 ucCmdS2,u8 ucCmdS3);
void car2_stop(void);
void car2_up(u8 ucSpeed,u16 uiMapan);
void car2_back(u8 ucSpeed,u16 uiMapan);
void car2_lift(u8 ucSpeed);
void car2_right(u8 ucSpeed);
void car2_track(u8 ucSpeed);
void car2_tracks(u8 ucSpeed);
void car2_leftd(u8 ucSpeed,u16 jd);
void car2_rightd(u8 ucSpeed,u16 jd);
void car2_infrared_Q3(u8 dat[]);
void car2_infrared_H3(u8 dat[]);
void car2_infrared(void);
void car2_led(u8 z,u8 y);
void car2_fmq(u8 kg);
void car2_img_up(void);
void car2_img_down(void);
void car2_GuangYuan(u8 dw);
void car2_updata(u8 kg);
void car2_yysb(u8 kg);
void car2_2WMsb(u8 kg);
void car2_proc(void);


#endif

