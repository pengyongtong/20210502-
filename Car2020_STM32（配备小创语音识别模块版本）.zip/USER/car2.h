#ifndef __CAR2_H
#define __CAR2_H 			   
#include "stm32f4xx.h"	
#define CAR2_USE    0 	
extern u8  gucCar2State;
extern u8  gucCar2GuangMin;
extern u16  guiCar2ChaoSB;
extern u16  guiCar2GuangQ;
extern u16  guiCar2MaPan;
void car2_proc(void);
#endif

