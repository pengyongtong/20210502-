#include <stdio.h>
#include "stm32f4xx.h"
#include "delay.h"
#include "infrared.h"
#include "cba.h"
#include "ultrasonic.h"
#include "canp_hostcom.h"
#include "hard_can.h"
#include "bh1750.h"
#include "syn7318.h"
#include "power_check.h"
#include "can_user.h"
#include "data_base.h"
#include "roadway_check.h"
#include "tba.h"
#include "data_base.h"
#include "swopt_drv.h"
#include "uart_a72.h"
#include "Can_check.h"
#include "delay.h"
#include "can_user.h"
#include "Timer.h"
#include "Rc522.h"
#include "wutishow.h"
#include "cardrive.h"

u8   ma[60]={0};
u8   twoerma_flg=0;
u8   erweima_flg=0;
u8   yanshe_flag=0;
u8   yanshe=0;
void  daoza_kg(u8 mode)//��բ������ر�
{
	 Stop_Flag=0;
    if(mode)
		{
		   Send_ZigbeeData_To_Fifo(DZ_K,8);
		}
		else{
		  Send_ZigbeeData_To_Fifo(DZ_G,8);
		}
		while(Stop_Flag !=0x05)
		{
		   if(Zigbee_Rx_flag)
			 {
			      if(Zigb_Rx_Buf [1]==0x03)
						{
						  if(Zigb_Rx_Buf[2]==0x01)
							{
							Stop_Flag=Zigb_Rx_Buf[4];  
							}
						}
			 }
		}
}
void  ETC_kg(void)//ETCͨ��
{
    Stop_Flag=0;
  while(Stop_Flag !=0x06)
		{
		   if(Zigbee_Rx_flag)
			 {
			      if(Zigb_Rx_Buf [1]==0x0c)
						{
						  if(Zigb_Rx_Buf[2]==0x01)
							{
							Stop_Flag=Zigb_Rx_Buf[4];  
							}
						}
			 }
		}
}
void  fenghuotai(void)//���̨
{
   Infrared_Send(HW_K,6);
}

void  guanyuan_show(void)
{
	u8  fh;
	fh=Get_Bh_Value();

	  switch(fh%4+1)
		{
			case 0:Infrared_Send(H_1,4);//��Դ��λ��1
			case 1:Infrared_Send(H_2,4);//��Դ��λ��2
			case 2:Infrared_Send(H_3,4);//��Դ��λ��3
			default:break;
		}
}
void  SMG(void)
{

	 u8 SMG_SHOW1[8]={0x55,0x04,0x02,0x00,0x00,0x00,0x00,0xBB};
	u8  i;
	for(i=0;i<15;i++)
	{
		SMG_SHOW1[5]=hc[i];
	  SMG_SHOW1[6]=(SMG_SHOW1[2]+SMG_SHOW1[5])%256;
		Send_ZigbeeData_To_Fifo(SMG_SHOW1, 8);
		delay_ms (300);
		delay_ms (300);
		delay_ms (300);
	}
}
void  liti_tuxing(u8  mode)
{
   switch(mode)
	 {
		 case 0:Infrared_Send(tuxing_show,6);break;//��ʾ����
		 case 1:Infrared_Send(tuxing_show1,6);break;//��ʾԲ��
		 case 2:Infrared_Send(tuxing_show2,6);break;//��ʾ������
		 case 3:Infrared_Send(tuxing_show3,6);break;//��ʾ����
		 case 4:Infrared_Send(tuxing_show4,6);break;//��ʾ����
		 case 5:Infrared_Send(tuxing_show5,6);break;//��ʾ��ͼ
		 case 6:Infrared_Send(tuxing_show6,6);break;//��ʾ��ͼ
		 case 7:Infrared_Send(tuxing_show7,6);break;//��ʾ����ͼ
		 default:break; 
	 }
}
void  liti_yanshe(u8  mode)
{
  switch(mode)
	{
	   case 0:Infrared_Send(yanshe_show,6);break;//��ʾ��ɫ
		 case 1:Infrared_Send(yanshe_show1,6);break;//��ʾ��ɫ
		 case 2:Infrared_Send(yanshe_show2,6);break;//��ʾ��ɫ
		 case 3:Infrared_Send(yanshe_show3,6);break;//��ʾ��ɫ
		 case 4:Infrared_Send(yanshe_show4,6);break;//��ʾ��ɫ
		 case 5:Infrared_Send(yanshe_show5,6);break;//��ʾ��ɫ
		 case 6:Infrared_Send(yanshe_show6,6);break;//��ʾ��ɫ
		 case 7:Infrared_Send(yanshe_show7,6);break;//��ʾ��ɫ
		 default:break; 
	}
}
void  liti_road(u8  mode)
{
   switch(mode)
	 {
		 case 0:Infrared_Send(road_show,6);break;
		 case 1:Infrared_Send(road_show1,6);break;
		 default:break;
	 }
}
void  liti_juli(void)
{
    u8  juli_show[6]={0xff,0x11,0x00,0x00,0x00,0x00};
		static  u8  shuzi[10]={0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39};
	   u16   data_h;//
   	 Ultrasonic_Ranging();	//����������						
		 data_h=dis;//�õ�����������	 

		 data_h=((data_h&0xf00)>>8)*256+((data_h&0x0f0)>>4)*16+(data_h&0x00f)*1;//������������ת����ʮ����
	   juli_show[2]=shuzi[data_h%100/10];
	   juli_show[3]=shuzi[data_h%10];
		 Infrared_Send(juli_show,6);
}
void  wuxian_power(u8  mode)
{ 
	switch(mode)
	{
		case 0:Send_ZigbeeData_To_Fifo(power_g , 8);break;
		case 1:Send_ZigbeeData_To_Fifo(power_k , 8);break;
		default:break;
}
	}
void Alarm_station(u8 *s) //�޸ı���̨�����뺯��    
{
	u8   Send_zigbee[8]={0};
    Send_zigbee[0]=0x55;
    Send_zigbee[1]=0x07;
    Send_zigbee[2]=0x10;
    Send_zigbee[3]=*(s+0);
    Send_zigbee[4]=*(s+1);
    Send_zigbee[5]=*(s+2);
    Send_zigbee[6]=(Send_zigbee[2]+Send_zigbee[3]+Send_zigbee[4]+Send_zigbee[5])%256;;
    Send_zigbee[7]=0xbb;
    delay_ms(10);
    for(int i=0; i<3; i++)
    {
        Send_ZigbeeData_To_Fifo(Send_zigbee,8);
        delay_ms(300);
    }
    Send_zigbee[2]=0x11;
    Send_zigbee[3]=*(s+3);
    Send_zigbee[4]=*(s+4);
    Send_zigbee[5]=*(s+5);
    Send_zigbee[6]=(Send_zigbee[2]+Send_zigbee[3]+Send_zigbee[4]+Send_zigbee[5])%256;;
    Send_zigbee[7]=0xbb;
    delay_ms(10);
    for(int i=0; i<3; i++)
    {
        Send_ZigbeeData_To_Fifo(Send_zigbee,8);
        delay_ms(300);
    }
}

void  send_2wm(void)//���Ͷ�ά��ʶ��������
{

  u8  txtbf[]={0X55,0X03,0X79,0X09,0X09,0X09,0X09,0X09,0X09,0X09,0X09,0X01};//��ά����ɫʶ����������	
	
	Send_WifiData_To_Fifo(txtbf,12);
	
	UartA72_TxClear();
	UartA72_TxAddStr(txtbf,12);
	UartA72_TxStart();	
	wifi_ZigBee_Rx();
}
void  read2wm(u8 *ao)//��ȡ��ά������
{
    u16  len=0,i;
	len=sizeof(Wifi_Rx_Buf)/sizeof(ma[0]);
	for(i=0;i<len-8;i++)
	{
		if(Wifi_Rx_Buf[8+i]==0xcc){twoerma_flg=0;break;}
	  ao[i]=Wifi_Rx_Buf[8+i];
	}
	if(ma[0]==0x7a)
		LED_L =0;
}

void  send_yanshe(void)//������ɫʶ��������
{
  u8  txtbf[]={0X55,0X03,0X79,0X09,0X09,0X09,0X09,0X09,0X09,0X09,0X09,0X02};//��ɫʶ����������
	
	Send_WifiData_To_Fifo(txtbf,12);
	
	UartA72_TxClear();
	UartA72_TxAddStr(txtbf,12);
	UartA72_TxStart();	
	wifi_ZigBee_Rx();
}

void  read_yanshe(void)
{
	if(yanshe_flag==1)
	{
   yanshe=Wifi_Rx_Buf[8];
		if(yanshe==0x01)
		{
		  LED_L=0;
		}
		yanshe_flag=0;
	}
}

void  yanshe_xs(u8 dd)
{
	 u8  i;
    switch(dd)
		{
		  case 0x01:LED_L=0;for(i=0;i<3;i++)Infrared_Send(yanshe_show,6);dd=0;break;//��ʾ��ɫ
			case 0x02:Infrared_Send(yanshe_show3,6);break;//��ʾ��ɫ
			case 0x03:Infrared_Send(yanshe_show1,6);break;//��ʾ��ɫ
			default:break;
		}
}


void  ceku(u8 mode,u8 zl)
{
    u8  ceku[8]={0x55,0x0D,0x00,0x00,0x00,0x00,0x00,0xbb};
		
		ceku[2]=mode;
		ceku[3]=zl;
		ceku[6]=(ceku[2]+ceku[3])%256;
		Send_ZigbeeData_To_Fifo(ceku,8);
		
}
void  jiaotongdeng(u8 mode,u8 zl)
{
    u8  jtd[8]={0x55,0x0e,0x00,0x00,0x00,0x00,0x00,0xbb};
		
		jtd[2]=mode;
		jtd[3]=zl;
		jtd[6]=(jtd[2]+jtd[3])%256;
		Send_ZigbeeData_To_Fifo(jtd,8);
		
}


