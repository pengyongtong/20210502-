#inndef   _car2diver_h
#define   _car2diver_h

#define   congce_stop    0x01
#define   congce_go      0x02
#define   congce_back    0x03
#define   congce_left    0x04  //
#define   congce_right   0x05  //
#define   congce_xj      0x06
#define   congce_mp      0x07
//#define   congce_


#endif