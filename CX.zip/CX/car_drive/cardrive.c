#include <stdio.h>
#include "stm32f4xx.h"
#include "delay.h"
#include "infrared.h"
#include "cba.h"
#include "ultrasonic.h"
#include "canp_hostcom.h"
#include "hard_can.h"
#include "bh1750.h"
#include "syn7318.h"
#include "power_check.h"
#include "can_user.h"
#include "data_base.h"
#include "roadway_check.h"
#include "tba.h"
#include "data_base.h"
#include "swopt_drv.h"
#include "uart_a72.h"
#include "Can_check.h"
#include "delay.h"
#include "can_user.h"
#include "Timer.h"
#include "Rc522.h"
#include "bkrc_voice.h"
#include "cardrive.h"
void  car_stop(void)
{
   Roadway_mp_syn();
	  Stop_Flag=0;
	  Go_Flag =1;
	  wheel_L_Flag =0;
	  wheel_R_Flag=0;
	  wheel_Nav_Flag=0;
	  Back_Flag =0;
	  Track_Flag =0;
	  temp_MP =0;
	  Car_Spend =0 ;
	  Control (Car_Spend ,Car_Spend );
}
void  car_go(u8 speed,u16  temp)//С��ǰ��
{
    Roadway_mp_syn();
	  Stop_Flag=0;
	  Go_Flag =1;
	  wheel_L_Flag =0;
	  wheel_R_Flag=0;
	  wheel_Nav_Flag=0;
	  Back_Flag =0;
	  Track_Flag =0;
	  temp_MP =temp;
	  Car_Spend =speed ;
	  Control (Car_Spend ,Car_Spend );
	  while(Stop_Flag!=0x03)
		{
		wifi_ZigBee_check(10);	
		}
}

void  car_back(u8 speed,u16  temp)   //С������
{
    Roadway_mp_syn();
	  Stop_Flag=0;
	  Go_Flag =0;
	  wheel_L_Flag =0;
	  wheel_R_Flag=0;
	  wheel_Nav_Flag=0;
	  Back_Flag =1;
	  Track_Flag =0;
	  temp_MP =temp;
	  Car_Spend =speed ;
	  Control (-Car_Spend ,-Car_Spend );
	  while( Stop_Flag!=0x03);
}

void  car_left(u8 speed) //С����ת
{
   	Stop_Flag = 0;
	  Go_Flag = 0;
	  wheel_L_Flag = 1;
	  wheel_R_Flag = 0;
	  wheel_Nav_Flag = 0;
		Back_Flag = 0;
 	  Track_Flag = 0;
		Car_Spend = speed;				
		Control(-Car_Spend ,Car_Spend);
	  while(Stop_Flag!=0x02)
		{
		  wifi_ZigBee_check(10);	
		}
}
void  car_right(u8 speed) //С����ת
{
	
    Stop_Flag = 0;
	  Go_Flag = 0;
	  wheel_L_Flag = 0;
	  wheel_R_Flag = 1;
	  wheel_Nav_Flag = 0;
		Back_Flag = 0;
 	  Track_Flag = 0;
		Car_Spend = speed;				
		Control(Car_Spend ,-Car_Spend);
	  while(Stop_Flag!=0x02)
	{
	  Read_Card (2);
		wifi_ZigBee_check(10);	
	}
}
void  car_xj(u8 speed) //С��ѭ��
{
	      u8  card_id;
   	    Stop_Flag = 0;
   	    Go_Flag = 0; 
	      wheel_L_Flag = 0;
	      wheel_R_Flag = 0;
	      wheel_Nav_Flag = 0;
				Back_Flag = 0; 
	      Track_Flag = 1;
				Car_Spend =speed ;
	      Control (Car_Spend ,Car_Spend );
	      while(Stop_Flag !=0x01)
				{
				   Read_Card(1);
					wifi_ZigBee_check(10);	
				}
}	
void  car_jiaodu(u8  mode,u8  speed,u8 temp)
{
//   			Roadway_nav_syn();	//�Ƕ�ͬ��
				Roadway_mp_syn();	//����ͬ��
				Stop_Flag = 0;
    	  Go_Flag = 0; 
	      wheel_L_Flag = 0;
	      wheel_R_Flag = 0;
	      wheel_Nav_Flag = 1;
				Back_Flag = 0; 
	      Track_Flag = 0;
				temp_Nav =temp ;
				Car_Spend = speed;
	      if(mode==1)
			Send_UpMotor(Car_Spend,-Car_Spend);
			  else 
			Send_UpMotor(-Car_Spend,Car_Spend);
			  while(Stop_Flag!=0x02);
					wifi_ZigBee_check(1);
			 Stop_Flag=0;
}  
void  car_ceju(void)
{
	   u8 SMG_SHOW2[8]={0x55,0x04,0x04,0x00,0x02,0x00,0x00,0xBB};//���������ݻ�����
		 u16   data_h;//
   	 Ultrasonic_Ranging();	//����������						
		 data_h=dis ;//�õ�����������	 

		 data_h=((data_h&0xf00)>>8)*256+((data_h&0x0f0)>>4)*16+(data_h&0x00f)*1;//������������ת����ʮ����

		SMG_SHOW2[4]=dm[data_h/100];//��Ű�λ
		SMG_SHOW2[5]=dm[data_h%100/10]<<4|dm[data_h%10];//��ŵ�λ�͸�λ
	  SMG_SHOW2[6]=(SMG_SHOW2[2]+SMG_SHOW2[3]+SMG_SHOW2[4]+SMG_SHOW2[5])%256;//�õ�У���
		Send_ZigbeeData_To_Fifo(SMG_SHOW2, 8);//���͸�LED��ʾ��־��
		delay_ms (300);
	}	
void  my_delay(u8  t)
{
   u8  i;
	for(i=0;i<t;i++)
	{
	  delay_ms(300);
	}
}

