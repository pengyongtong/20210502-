#include "infrared.h"
#include "cba.h"
#include "ultrasonic.h"
#include "canp_hostcom.h"
#include "hard_can.h"
#include "bh1750.h"
#include "syn7318.h"
#include "power_check.h"
#include "can_user.h"
#include "data_base.h"
#include "roadway_check.h"
#include "tba.h"
#include "data_base.h"
#include "swopt_drv.h"
#include "uart_a72.h"
#include "Can_check.h"
#include "can_user.h"
#include "Timer.h"
#include "Rc522.h"
#include "cardrive.h"
#include "delay.h"
#include "wutishow.h"
void  road_one(void)
{
	u8  i;
	
	 Send_ZigbeeData_To_Fifo(SMG_JSK,8);
		
	 car_xj(50);
	 car_go(50,460);
	 my_delay(1);
	
	car_right(90);
	my_delay(1);
	
	for(i=0;i<8;i++)
	{
	  car_jiaodu(1,90,45);
	}
//	 car_ceju();//С����࣬
	my_delay(15);
send_2wm();
	my_delay(1);
send_2wm();
	my_delay(1);	
	for(i=0;i<12;i++)
	{
	  car_jiaodu(0,90,45);
	}
	 yanshe_xs(yanshe);
		my_delay(6);
	 yanshe_xs(yanshe);
		my_delay(6);
	 yanshe_xs(yanshe);
	my_delay(6);
	 yanshe_xs(yanshe);
	my_delay(6);
	 yanshe_xs(yanshe);
	my_delay(6);
	liti_juli();//���͸�������ʾ��־��
	
		for(i=0;i<8;i++)
	{
	  car_jiaodu(0,90,45);
	}
	
//	 car_xj(50);
//	 car_go(50,460);//
//	 my_delay(1);//
//	 daoza_kg(1);//������բ
//	 my_delay(1);//�ȴ���բ��ȫ����
//	 car_xj(50);//ͨ����բ�������в���Ѱ�� 
//	 car_go(50,460);//
//	  my_delay(2);//
//	  send_2wm();
//	  while(!twoerma_flg);
//	
//	 LED_R =0;//������ת���
//	 FM=1;//�򿪷�����
//	 car_right(90);//��ת��λ
//   my_delay(1);
//	 LED_R =1;//�ر���ת���
//	 FM=0;//�رշ�����
//   my_delay(1);	
//	
//	 car_xj(50);
//	 car_go(50,300);
//	 my_delay(1);//�ȴ�ETCբ�ſ������
//	 car_xj(50);
//	 car_go(50,800);
//	 guanyuan_show();//ʶ��ǰ��Դǿ�ȣ�������
//	 my_delay(2);
//	 car_back(50,300);
//	 my_delay(1);
//	 
//	 for(i=0;i<12;i++)
//	 {
//	   car_jiaodu(1,90,45);
//	 }
//	 car_ceju();
//	 my_delay(2);//��࣬С���뾲ֹ��־��ľ���
//	 for(i=0;i<8;i++)
//	 {
//	   car_jiaodu(1,90,45);
//	 }
//	 my_delay(1);
//	 car_xj(50);
//	 car_go(50,400);
//	 my_delay(1);
//	 
//	  for(i=0;i<12;i++)
//	 {
//	   car_jiaodu(1,90,45);
//	 }
//	  Infrared_Send(recive_kqm,6);//��������̨
//	  my_delay(1);
//	  for(i=0;i<12;i++)
//	 {
//	   car_jiaodu(0,90,45);
//	 }
//	 car_xj(50);
//	 car_go(50,460);
//	 my_delay(1);
//	 
//	 LED_L =0;
//	 FM=1;
//	 car_left(90);
//	 my_delay(1);
//	  LED_L =1;
//	 FM=0;
//	 car_go(50,300);
//	 my_delay(1);
//	 SYN7318_Extern();//�����������
//	 my_delay(4);
//	 car_back(50,300);
//	  my_delay(1);
//	 
//	 LED_R =0;
//	 FM=1;
//	 car_right(90);
//	  wuxian_power(1);
//			 my_delay(1);
//	  for(i=0;i<12;i++)
//	 {
//	   car_jiaodu(1,90,45);
//	 }
//	 my_delay(1);
//	  for(i=0;i<8;i++)
//	 {
//	   car_jiaodu(1,90,45);
//	 }
//	  my_delay(1);
//	  LED_R =1;
//	  FM=0;
//	  car_xj(50);
//	  car_go(50,460);
//	  car_xj(50);
//	  car_go(50,460);
//	  my_delay(1);
//	  LED_R =0;
//	  FM=1;
//	  car_right(90);
//	  my_delay(1);
//	  LED_R =1;
//	  FM=0;
//	 my_delay(2);
//	  car_go(50,300);
//	 my_delay(1);
//	 car_back(50,1000);

}

